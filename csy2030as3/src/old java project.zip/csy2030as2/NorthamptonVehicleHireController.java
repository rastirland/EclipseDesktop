package csy2030as2;
import java.util.ArrayList;
import java.util.Arrays;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import csy2030as2.vehicle;

public class NorthamptonVehicleHireController implements ActionListener
{
	NorthamptonVehicleHireModel model;
	NorthamptonVehicleHireView view;
	ArrayList<vehicle> vehicle_list = new ArrayList<vehicle>();
	ArrayList<customer> customer_list = new ArrayList<customer>();
		public NorthamptonVehicleHireController(NorthamptonVehicleHireModel model)
		{
			this.model = model;
			
			
			
		}
		
		
		public void addView(NorthamptonVehicleHireView view){
			this.view = view;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if (e.getActionCommand() == "works") {
				if (model.validLogin(view.getuserName() , view.getpassword()) == true) {
					view.mainwindow();
					view.hiddenlogin();
//					view.editvehicleData();
//					view.editcustomersData();
					System.out.println("in log int");
//					ArrayList<vehicle> vehicle_list = new ArrayList<vehicle>();
//					ArrayList<customer> customer_list = new ArrayList<customer>();
//					view.initTable(vehicle_list);
//					view.initTable2(customer_list);
					
					
					try {
						FileInputStream fis = new FileInputStream("C:\\Users\\rasti\\eclipse-workspace\\csy2030as2\\src\\csy2030as2\\vehicles.dat");
						ObjectInputStream ois = new ObjectInputStream(fis);

						vehicle obj = null;
			        	
						while ((obj=(vehicle)ois.readObject())!=null) {
							vehicle_list.add(obj);
							System.out.println(vehicle_list + "hello");
							
						
					}
					            ois.close();
						
					        	model.create_list(vehicle_list);
								

											          

						 } catch (EOFException ex) {  //This exception will be caught when EOF is reached
						            System.out.println("*vehicle* End of file reached.");
						        }  catch (FileNotFoundException ex) {
						            ex.printStackTrace();
						        } catch (IOException ex) {
						            ex.printStackTrace();
						        } catch (ClassNotFoundException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								} 
					
				try {
					FileInputStream fis = new FileInputStream("C:\\Users\\rasti\\eclipse-workspace\\csy2030as2\\src\\csy2030as2\\customers.dat");
					ObjectInputStream ois = new ObjectInputStream(fis);

					customer obj = null;
		        	
					while ((obj=(customer)ois.readObject())!=null) {
						customer_list.add(obj);
					
				}
				            ois.close();
					
				        	model.create_customerlist(customer_list);
										          

					 } catch (EOFException ex) {  //This exception will be caught when EOF is reached
					            System.out.println("*customer* End of file reached.");
					        }  catch (FileNotFoundException ex) {
					            ex.printStackTrace();
					        } catch (IOException ex) {
					            ex.printStackTrace();
					        } catch (ClassNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} 
					}
		
			}
			
if (e.getActionCommand() == "deleteCustomer") {
				

				view.editcustomersData();
				view.initTable2(customer_list);
				System.out.println("in delete Customer gui");
				}
if (e.getActionCommand() == "deleteVehicleGui") {
				
				view.editvehicleData();
				view.initTable(vehicle_list);
				view.editcustomersData();
				view.initTable2(customer_list);
				System.out.println("in delete vehicle gui");
				}
			
if (e.getActionCommand() == "Add_mbus") {
				
				view.addmbus();
				System.out.println("in add Mini Bus");
				}
if (e.getActionCommand() == "Add_Lorry") {
				
				view.addlorry();
				System.out.println("in add lorry");

				}
if (e.getActionCommand() == "addveh") {
				
				view.addvehicle();
				System.out.println("in add vehicle");
				}
			
if (e.getActionCommand() == "Add_Car") {
				
				view.addcar();
				System.out.println("in add car");
				}
			
if (e.getActionCommand() == "addcust") {
				
				view.addcustomer();
				System.out.println("in add Customer");
			
				}
if (e.getActionCommand() == "addminibus") {
    
    view.addmbus();
    System.out.println("****in add a new MiniBus****");

    model.addnewminibus(view.getMake(), view.getModel(), Integer.parseInt(view.getTopSpeed()), view.getReg(), view.getHire(), view.getSeatCapacity());

    }
if (e.getActionCommand() == "addlorry") {
    
    view.addlorry();
    System.out.println("****in add a new Lorry****");

    model.addnewlorry(view.getMake(), view.getModel(), Integer.parseInt(view.getTopSpeed()), view.getReg(), view.getHire(), view.getHoldCapacity());

    }
if (e.getActionCommand() == "addcar") {
    
    view.addcar();
    System.out.println("****in add a new car****");

    model.addnewcar(view.getMake(), view.getModel(), Integer.parseInt(view.getTopSpeed()), view.getReg(), view.getHire(), view.getNumberOfDoors(), view.getFuelType());

    }
if (e.getActionCommand() == "Save_Button") {
				
				//view.addvehicle();
				System.out.println("in save");
//				model.addnewcar(view.getModel(), view.getMake(), view.getTopSpeed(), view.getReg(), view.getHire(), 4, "petrol");
				//model.addnewcar("bmw", "series", 120, "bmw120", 150, 4, "petral");	
				//model.addnewcar("ford", "focus", 115, "focus12", 180, 5, "diesel");
				}

if (e.getActionCommand() == "Save") {
	

	System.out.println("in save");
	model.addnewcustomer( view.getCustomerId(), view.getName(), view.getAddress(), view.getPhoneNumber(), view.getEmailAddress(), view.getcUserName(), view.getcpassword());

			
}
		
if (e.getActionCommand() == "logout") {
	System.out.println("in log out");
	ArrayList<vehicle> vehicle_list = model.get_list();
	ArrayList<customer> customer_list = model.get_customerlist();
	try {
		FileOutputStream fos = new FileOutputStream("C:\\\\Users\\\\rasti\\\\eclipse-workspace\\\\csy2030as2\\\\src\\\\csy2030as2\\\\vehicles.dat");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		int i;
		for (i=0; i<vehicle_list.size(); i++)
			oos.writeObject(vehicle_list.get(i));
		System.out.println("i = " + i);
		oos.close();

							          

		 } catch (EOFException ex) {  //This exception will be caught when EOF is reached
		            System.out.println("End of file reached.");
		        }  catch (FileNotFoundException ex) {
		            ex.printStackTrace();
		        } catch (IOException ex) {
		            ex.printStackTrace();
		        }
	try {
		FileOutputStream fos = new FileOutputStream("C:\\\\Users\\\\rasti\\\\eclipse-workspace\\\\csy2030as2\\\\src\\\\csy2030as2\\\\customers.dat");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		int i;
		for (i=0; i<customer_list.size(); i++)
			oos.writeObject(customer_list.get(i));
		System.out.println("i = " + i);
		oos.close();

							          

		 } catch (EOFException ex) {  //This exception will be caught when EOF is reached
		            System.out.println("End of file reached.");
		        }  catch (FileNotFoundException ex) {
		            ex.printStackTrace();
		        } catch (IOException ex) {
		            ex.printStackTrace();
		        } 


	
	   
//	System.exit(0);
		}
	


		}
}

