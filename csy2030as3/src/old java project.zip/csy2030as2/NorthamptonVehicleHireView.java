package csy2030as2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.*;

import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;


public class NorthamptonVehicleHireView extends JFrame {
//variables
NorthamptonVehicleHireModel model;
NorthamptonVehicleHireController controller;
JPanel panel;
JLabel user_label, password_label, message, user_label1 ;
JTextField userName_text;
JTextField password_text;
JButton submit, cancel;
JFrame l = new JFrame();
JFrame m = new JFrame();
JFrame avc = new JFrame();
JFrame vmb = new JFrame();
JFrame av = new JFrame();
JFrame ac = new JFrame();
JFrame avl = new JFrame();
JFrame editvehiclegui = new JFrame();
//private JPanel av;

private JTextField vtoptex = new JTextField();
private JTextField vhiretex = new JTextField();
private JTextField cdoorstex = new JTextField();
private JTextField vregtex = new JTextField();
private JTextField vnametex = new JTextField();
private JTextField vmodeltex = new JTextField();
private JButton vcarsavebutton;
private JButton vresetbutton;

// car
private String[] fueldtypes = {"Petrol", "Deisel"};
private JComboBox vfuelselect = new JComboBox(fueldtypes);

private JButton buttoncheck;
//minibus
private String[] vmbseatcap = {"8","16"};
private JComboBox vmbseatcap1 = new JComboBox(vmbseatcap);
private JTextField vmbametex;
private JTextField vmbmodeltex;
private JTextField vmbregtex;
private JTextField vmbtoptex;
private JTextField vmbhiretex;
private JButton vmbsavebutton;
private JButton vmbresetbutton;
private JLabel vmbcapacity;

//lorry
private String[] vlweight = {"7","12","40"};
private JComboBox vlweight1 = new JComboBox(vlweight);
private JTextField vlnametex;
private JTextField vlmodeltex;
private JTextField vlregtex;
private JTextField vltoptex;
private JTextField vlhiretex;
private JButton vlsavebutton;
private JButton vlresetbutton;
private JLabel cdoors;
private JLabel lmaxweight;
//private JComboBox vlweight;

// global ac
private JTextField clnametex;
private JTextField claddresstex;
private JTextField clphonenumtex;
private JTextField clemailaddresstex;
private JTextField clusernametex;
private JTextField clpasswordtex;
private JTextField clidtex;
private JPanel clontentPane;
private JTextField textField;





JLabel cFuelType;


JList list;

// global ac
private JTextField cnametex;
private JTextField caddresstex;
private JTextField cphonenumtex;
private JTextField cemailaddresstex;
private JTextField cusernametex;
private JTextField cpasswordtex;
private JTextField cidtex;

//main window buttons and labels
//JLabel staffwel = new JLabel("Welcome Staff");
JButton staffwel = new JButton("Log Out");
JButton buttonaddvehicle = new JButton("Add vehicle");
JButton buttondelvehicle = new JButton("Delete vehicle");
JButton buttonviewloaned = new JButton("view Loaned vehicles");
JButton buttonhire = new JButton("hire vehicles");
JButton buttonsreturn = new JButton("return vehicles");
JButton buttonaddcustomer = new JButton("Add a new customer");
JButton buttondelcustomer = new JButton("Delete customer");
public NorthamptonVehicleHireView(NorthamptonVehicleHireModel model, NorthamptonVehicleHireController controller)
{
// constructor
this.model = model;
this.controller = controller;
login();
//mainwindow();
controller.addView(this);
}
public void login() {
     // Username Label
    user_label1 = new JLabel();
    user_label1.setText("   hello my name is    ");
     
     user_label = new JLabel();
     user_label.setText("User Name :");
     userName_text = new JTextField();
     // Password Label
     password_label = new JLabel();
     password_label.setText("Password :");
     password_text = new JTextField();
     // Submit
     submit = new JButton("SUBMIT");
     panel = new JPanel(new GridLayout(6, 3));
     submit.setActionCommand("works");
     panel.add(user_label);
     panel.add(userName_text);
     panel.add(password_label);
     panel.add(password_text);
     message = new JLabel();
     panel.add(message);
     panel.add(submit);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     // Adding the listeners to components..
     submit.addActionListener(controller);
     add(panel, BorderLayout.CENTER);
     setTitle("Northampton Vehcile Hire - Login");
     l.setSize(250,350);
     l.setVisible(true);
     l.add(panel);
     l.setResizable(false);
  }
private JButton btnNewButton;
private JLabel lblNewLabel;

private JTable j = new JTable();


	private JTable table;
	private JTable table2;

//	private JTable j = new JTable();

	private Object[][] data;
	private String[] columnNames;
	private String[] columnNames2;
	private JButton button;
	private JButton button2;
	 private DefaultTableModel fmodel;
	 private DefaultTableModel fmodel2;
public void editvehicleData() {
	


	
	    
	    setTitle("Edit/delete Vehicle Data");
//	    data = new Object[][] {{"test1", "test1","test1", "test1"}, {"test2", "test2","test2", "test2"}};
//	    fmodel.addRow(new Object[]{vehicle.getMake(), vehicle.getModel(), vehicle.getTopSpeed(), vehicle.getRegNum(), vehicle.getDailyHireRate()});
	    columnNames = new String[] {"Make", "Model", "Top Speed", "Reg Number", "Dailyhire Rate"};
	    fmodel = new DefaultTableModel(data, columnNames);
	    
//	    fmodel.addRow{vehicle.getMake(), vehicle.getModel(), vehicle.getTopSpeed(), vehicle.getRegNum(), vehicle.getDailyHireRate()};
//	    fmodel.addRow(new Object[]{vehicle.getMake(), vehicle.getModel(), vehicle.getTopSpeed(), vehicle.getRegNum(), vehicle.getDailyHireRate()});
	    table = new JTable(fmodel);
	    table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
	    button = new JButton("Remove");
	    
	    
	   
	    add(new JScrollPane(table), BorderLayout.CENTER);
	    add(button, BorderLayout.SOUTH);

	    setSize(400, 300);
	    setLocationRelativeTo(null);
	    setVisible(true);
	      
	}
 	

public void initTable(ArrayList<vehicle> vehicle_list) {

	 
	     for(vehicle vcar : vehicle_list){
	    	 
	          fmodel.addRow(new Object[]{vcar.getMake(), vcar.getModel(), vcar.getTopSpeed(), vcar.getRegNum(), vcar.getDailyHireRate()});
	           System.out.println(vcar.getTopSpeed() + "test");
	     }
	     table.setModel(fmodel);
	}

public void editcustomersData() {
	


	
    
    setTitle("Edit/delete customer Data");

    columnNames2 = new String[] {"Id", "Name", "Address", "PhoneNum", "Email","Username" , "Password"};
    fmodel2 = new DefaultTableModel(data, columnNames2);
    table2 = new JTable(fmodel);
    table2.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
    button2 = new JButton("Remove");
    
    
   
    add(new JScrollPane(table2), BorderLayout.CENTER);
    add(button2, BorderLayout.SOUTH);

    setSize(400, 300);
    setLocationRelativeTo(null);
    setVisible(true);
      
}
	

public void initTable2(ArrayList<customer> customer_list) {

 
     for(customer Ccustomer : customer_list){
    	 
          fmodel2.addRow(new Object[]{Ccustomer.getCustomerId(), Ccustomer.getName(), Ccustomer.getAddress(), Ccustomer.getPhoneNumber(), Ccustomer.getEmailAddress(), Ccustomer.getUserName(), Ccustomer.getcPassword()});
           System.out.println(Ccustomer.getName() + "test");
     }
     table2.setModel(fmodel2);
}











public void mainwindow() {
 
 
     m.setBounds(100, 100, 728, 401);
     m.setVisible(true);    
     m.setLocation(550, 300);
     m.setLayout(new GridLayout(0, 4, 0, 0));
     
     m.add(staffwel);

	    
	   staffwel.addActionListener(controller);
	  staffwel.setActionCommand("logout");

	  
	  
  m.add(buttonaddvehicle);
  buttonaddvehicle.addActionListener(controller);
  buttonaddvehicle.setActionCommand("addveh");
  m.add(buttondelvehicle);
  buttondelvehicle.addActionListener(controller);
  buttondelvehicle.setActionCommand("deleteVehicleGui");
  m.add(buttonviewloaned);
  m.add(buttonhire);
  m.add(buttonsreturn);
  m.add(buttonaddcustomer);
  buttonaddcustomer.addActionListener(controller);
  buttonaddcustomer.setActionCommand("addcust");
  m.add(buttondelcustomer);
  buttondelcustomer.addActionListener(controller);
  buttondelcustomer.setActionCommand("deleteCustomer");
 
 
  }
public void addmbus() {
	
	vmb.setBounds(100, 100, 728, 401);
    vmb.setVisible(true);    
    vmb.setLocation(550, 300);
vmb.getContentPane().setLayout(new GridLayout(4, 2, 4, 0));
vmb.setResizable(false);
 JLabel vmbame = new JLabel("Name");
 vmb.getContentPane().add(vmbame);
// vnametex = new JTextField();
 vmb.getContentPane().add(vnametex);
 vnametex.setColumns(10);
 JLabel vmbmodel = new JLabel("Model");
 vmb.getContentPane().add(vmbmodel);
// vmodeltex = new JTextField();
 vmb.getContentPane().add(vmodeltex);
 vmodeltex.setColumns(10);
 JLabel vmbtopspeed = new JLabel("Top Speed");
 vmb.getContentPane().add(vmbtopspeed);
// vtoptex = new JTextField();
 vmb.getContentPane().add(vtoptex);
 vtoptex.setColumns(10);
 JLabel vmbregnum = new JLabel("Registration Number");
 vmb.getContentPane().add(vmbregnum);
// vregtex = new JTextField();
 vmb.getContentPane().add(vregtex);
 vregtex.setColumns(10);
 JLabel vmbdailyhirer = new JLabel("Daily Hire Rate");
 vmb.getContentPane().add(vmbdailyhirer);
// vhiretex = new JTextField();
 vmb.getContentPane().add(vhiretex);
 vhiretex.setColumns(10);
//unique to MiniBus
 vmbcapacity = new JLabel("Seat Capacity");
 vmb.getContentPane().add(vmbcapacity);
 vmb.getContentPane().add(vmbseatcap1);
 
 vmbsavebutton = new JButton("Save");
 vmbsavebutton = new JButton("Save Lorry");
 vmbsavebutton.addActionListener(controller);
 vmbsavebutton.setActionCommand("addminibus");
 vmb.getContentPane().add(vmbsavebutton);
 

 
 vmbresetbutton = new JButton("Reset");
 vmbresetbutton.setActionCommand("Reset_Button");
 vmb.getContentPane().add(vmbresetbutton);
	
}
public void addlorry() {
	
	avl.setBounds(100, 100, 728, 401);
    avl.setVisible(true);    
    avl.setLocation(550, 300);
avl.getContentPane().setLayout(new GridLayout(4, 2, 4, 0));
avl.setResizable(false);
 JLabel vlname = new JLabel("Name");
 avl.getContentPane().add(vlname);

 avl.getContentPane().add(vnametex);
 vnametex.setColumns(10);
 JLabel vlmodel = new JLabel("Model");
 avl.getContentPane().add(vlmodel);

 avl.getContentPane().add(vmodeltex);
 vmodeltex.setColumns(10);
 JLabel vltopspeed = new JLabel("Top Speed");
 avl.getContentPane().add(vltopspeed);

 avl.getContentPane().add(vtoptex);
 vtoptex.setColumns(10);
 JLabel vlregnum = new JLabel("Registration Number");
 avl.getContentPane().add(vlregnum);

 avl.getContentPane().add(vregtex);
 vregtex.setColumns(10);
 JLabel vdailyhirer = new JLabel("Daily Hire Rate");
 avl.getContentPane().add(vdailyhirer);

 avl.getContentPane().add(vhiretex);
 vhiretex.setColumns(10);


//unique to lorry
 lmaxweight = new JLabel("Max Load weight (tons)");
 avl.getContentPane().add(lmaxweight);

 avl.getContentPane().add(vlweight1);
 
 vlsavebutton = new JButton("Save Lorry");
 vlsavebutton.addActionListener(controller);
 vlsavebutton.setActionCommand("addlorry");
 avl.getContentPane().add(vlsavebutton);


 
 vlresetbutton = new JButton("Reset");
 vlresetbutton.setActionCommand("Reset_Button");
 avl.getContentPane().add(vlresetbutton);
	
	


	
	
}
public void addcar() {
	System.out.println("in addcar()");
	avc.setBounds(100, 100, 728, 401);
    avc.setVisible(true);    
    avc.setLocation(550, 300);
avc.getContentPane().setLayout(new GridLayout(4, 2, 4, 0));
avc.setResizable(false);
 JLabel vname = new JLabel("Name");
 avc.getContentPane().add(vname);


 avc.getContentPane().add(vnametex);
 vnametex.setColumns(10);

 JLabel vmodel = new JLabel("Model");
 avc.getContentPane().add(vmodel);

// vmodeltex = new JTextField();
 avc.getContentPane().add(vmodeltex);
 vmodeltex.setColumns(10);

 JLabel vtopspeed = new JLabel("Top Speed");
 avc.getContentPane().add(vtopspeed);


 avc.getContentPane().add(vtoptex);
 vtoptex.setColumns(10);

 JLabel vregnum = new JLabel("Registration Number");
 avc.getContentPane().add(vregnum);


 avc.getContentPane().add(vregtex);
 vregtex.setColumns(10);

 JLabel vdailyhirer = new JLabel("Daily Hire Rate");
 avc.getContentPane().add(vdailyhirer);


 avc.getContentPane().add(vhiretex);
 vhiretex.setColumns(10);
// unique to car
 JLabel cdoors = new JLabel("Number of doors");
 avc.getContentPane().add(cdoors);
 

 avc.getContentPane().add(cdoorstex);
// cdoorstex.setColumns(10);

 JLabel cFuelType = new JLabel("Fuel Type");
 avc.getContentPane().add(cFuelType);


 avc.getContentPane().add(vfuelselect);



 vcarsavebutton = new JButton("Save car");
 
 vcarsavebutton.addActionListener(controller);
 vcarsavebutton.setActionCommand("addcar");
 avc.getContentPane().add(vcarsavebutton);

 vresetbutton = new JButton("Reset");
 vresetbutton.setActionCommand("Reset_Button");
 avc.getContentPane().add(vresetbutton);
// avc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 avc.remove(avc);
 avc.revalidate();
 avc.repaint();
	
}

// this gets the base vehicle requirments
public String getModel()
{
return vmodeltex.getText();
}
public String getMake()
{
return vnametex.getText();
}

public String getTopSpeed()
{
return vtoptex.getText();
}
public String getReg()
{
return vregtex.getText();
}

public double getHire()
{
	
return Double.parseDouble(vhiretex.getText());

}

//this is the unique car getters/setters
public String getFuelType()
{
	 System.out.println(this.vfuelselect.getSelectedItem() + "fuel type");
return vfuelselect.getSelectedItem().toString(); 
}
public int getNumberOfDoors()
{
return Integer.parseInt(cdoorstex.getText());

}


// this is the unique lorry getters/setters
public int getHoldCapacity()
{	 System.out.println(this.vlweight1.getSelectedItem() + " ammount of weight");
	return Integer.parseInt((String)vlweight1.getSelectedItem());
}

//this is the unique Minibus getters/setters
public int getSeatCapacity()
	{	 System.out.println(this.vmbseatcap1.getSelectedItem() + " ammount of seats");
return Integer.parseInt((String)vmbseatcap1.getSelectedItem());
	}
	
// this loads vehicle selection screen
public void addvehicle() {
	av.setBounds(100, 100, 428, 401);
	av.setVisible(true); 
	av.setLayout(new GridLayout(0, 1, 1, 0));
	av.setResizable(false);
	
	JLabel selectveh = new JLabel("Select vehical");
	av.add(selectveh);
	
	JButton adcarButton = new JButton("Add Car");
	adcarButton.addActionListener(this.controller);
	adcarButton.setActionCommand("Add_Car");
	av.add(adcarButton);
	
	JButton adlorryButton = new JButton("Add Lorry");
	adlorryButton.addActionListener(this.controller);
	adlorryButton.setActionCommand("Add_Lorry");
	av.add(adlorryButton);
	
	JButton AdminibusButton = new JButton("Add MiniBus");
	AdminibusButton.addActionListener(this.controller);
	AdminibusButton.setActionCommand("Add_mbus");
	av.add(AdminibusButton);
     
}



public void addcustomer() {
ac.setBounds(100, 100, 728, 401);
     ac.setVisible(true);    
     ac.setLocation(550, 300);
ac.setLayout(new GridLayout(4, 2, 4, 0));
ac.setResizable(false);
JLabel cname = new JLabel("Name");
ac.add(cname);
cnametex = new JTextField();
ac.add(cnametex);
cnametex.setColumns(10);
JLabel caddress = new JLabel("Address");
ac.add(caddress);
caddresstex = new JTextField();
ac.add(caddresstex);
caddresstex.setColumns(10);
JLabel cphonenum = new JLabel("Phone Number");
ac.add(cphonenum);
cphonenumtex = new JTextField();
ac.add(cphonenumtex);
cphonenumtex.setColumns(10);
JLabel cemailaddress = new JLabel("Email Address");
ac.add(cemailaddress);
cemailaddresstex = new JTextField();
ac.add(cemailaddresstex);
cemailaddresstex.setColumns(10);
JLabel cusername = new JLabel("Username");
ac.add(cusername);
cusernametex = new JTextField();
ac.add(cusernametex);
cusernametex.setColumns(10);
JLabel cpassword = new JLabel("Password");
ac.add(cpassword);
cpasswordtex = new JTextField();
cpasswordtex.setColumns(10);
ac.add(cpasswordtex);
cidtex = new JTextField();
cidtex.setColumns(10);
ac.add(cidtex);
JButton btncsave = new JButton("Save");
btncsave.addActionListener(this.controller);
btncsave.setActionCommand("Save");
ac.add(btncsave);
JButton btncreset = new JButton("Reset");
ac.add(btncreset);
}
public  int getCustomerId()
{
return Integer.parseInt(cidtex.getText());
}

public String getName()
{
return cnametex.getText();
}
public String getAddress()
{
return caddresstex.getText();
}
public  int getPhoneNumber()
{
return Integer.parseInt(cphonenumtex.getText());
}
public String getEmailAddress()
{
return cemailaddresstex.getText();
}
public String getcUserName()
{
return cusernametex.getText();
}
public String getcpassword()
{
return cpasswordtex.getText();
}
  public void hiddenlogin() {
 
  l.setVisible(false);
  }
public String getuserName()
{
return userName_text.getText();
}
public String getpassword()
{
return password_text.getText();
}
}