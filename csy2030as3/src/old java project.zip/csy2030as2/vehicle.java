package csy2030as2;

import java.io.Serializable;

public class vehicle implements Serializable {
	protected String make;
	protected String model;
	protected int topSpeed;
	protected String regNum;
	protected double dailyHireRate;
	
	public vehicle(String make, String model, int topSpeed, String regNum, double dailyHireRate) {
		// constructor
		this.make = make;
		this.model = model;
		this.topSpeed = topSpeed;
		this.regNum = regNum;
		this.dailyHireRate = dailyHireRate;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getTopSpeed() {
		return topSpeed;
	}
	public void setTopSpeed(int topSpeed) {
		this.topSpeed = topSpeed;
	}
	public String getRegNum() {
		return regNum;
	}
	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
	public double getDailyHireRate() {http://marketplace.eclipse.org/marketplace-client-intro?mpc_install=4008412
		return dailyHireRate;
	}
	public void setDailyHireRate(double dailyHireRate) {
		this.dailyHireRate = dailyHireRate;
	}

}
